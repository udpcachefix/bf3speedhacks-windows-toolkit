NVIDIA Inspector launcher bundle

Contains the Apply and Revert launchers plus both required .nip profile files.
Keep all files in the same folder.

inspector.exe is not included in this bundle. The supplied CMD launchers automatically download inspector.exe if it is missing.

Apply: run Apply_NVIDIA_Inspector_Settings.cmd
Revert: run Revert_NVIDIA_Inspector_Settings_Only.cmd
