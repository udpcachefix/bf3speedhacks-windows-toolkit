BF3Speedhacks Windows Toolkit

Keep both files in the same folder. Run Run-Universal-Network-Reset-MTU1492.cmd.
The CMD launcher calls Universal-Network-Reset-MTU1492.ps1 from its own folder.
